#!/bin/sh
java -jar ../lib/jump3r-1.0.3.jar