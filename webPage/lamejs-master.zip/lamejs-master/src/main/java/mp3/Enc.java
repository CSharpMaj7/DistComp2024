package mp3;

public class Enc {
	public int enc_delay = -1;
	public int enc_padding = -1;
}
