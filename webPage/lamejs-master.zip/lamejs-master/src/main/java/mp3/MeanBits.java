package mp3;

public class MeanBits {
	public MeanBits(final int meanBits) {
		bits = meanBits;
	}

	int bits;
}