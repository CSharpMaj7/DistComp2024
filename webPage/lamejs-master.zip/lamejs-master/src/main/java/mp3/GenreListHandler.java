package mp3;

public interface GenreListHandler {
	void genre_list_handler(int num, String name);
}