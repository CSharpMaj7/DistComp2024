function MeanBits(meanBits) {
    this.bits = meanBits;
}

module.exports = MeanBits;
